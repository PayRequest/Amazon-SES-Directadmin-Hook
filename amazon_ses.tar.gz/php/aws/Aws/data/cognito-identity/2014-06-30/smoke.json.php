<?php
// This file was auto-generated from sdk-root/src/data/cognito-identity/2014-06-30/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListIdentityPools', 'input' => [ 'MaxResults' => 10, ], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeIdentityPool', 'input' => [ 'IdentityPoolId' => 'us-east-1:aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee', ], 'errorExpectedFromService' => true, ], ],];
